let count = 0;
let timeLeft = 10;
let timerId;
let cps = 0;

const cpsDisplay = document.getElementById("cps");
const clickBtn = document.getElementById("clickbtn");
const timeDisplay = document.getElementById("time");
const countDisplay = document.getElementById("count"); 

clickBtn.addEventListener("click", () =>{
    count = count + 1;
    countDisplay.textContent = count;
    if(timeLeft!=10){
        cps = count / (10-timeLeft);
        cpsDisplay.textContent = cps;
    }
    else cpsDisplay.textContent = 0;
});

function StartGame(){
    count = 0;
    countDisplay.textContent = count;
    timeDisplay.textContent = timeLeft;

    clickBtn.disabled = false;

    timerId = setInterval( ()=>{
        timeLeft = timeLeft - 1;
        timeDisplay.textContent = timeLeft;

    if(timeLeft <= 0){
        clearInterval(timerId);
        clickBtn.disabled = true;
        alert("Время вышло! Вы кликнули " + count + " раз.")
    }
    }, 1000);
}
function RestartGame(){
    count = 0;
    timeLeft = 10;
    countDisplay.textContent = count;
    timeDisplay.textContent = timeLeft;

    clickBtn.disabled = false;

    timerId = setInterval( ()=>{
        timeLeft = timeLeft - 1;
        timeDisplay.textContent = timeLeft;

    if(timeLeft <= 0){
        clearInterval(timerId);
        clickBtn.disabled = true;
        alert("Время вышло! Вы кликнули " + count + " раз.")
    }
    }, 1000);
}
function nM(){
    timeLeft = timeLeft - 1;
}
function nP(){
    timeLeft = timeLeft + 1;
}